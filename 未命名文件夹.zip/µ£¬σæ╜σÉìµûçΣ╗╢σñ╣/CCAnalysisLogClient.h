
#import <Foundation/Foundation.h>
#import "CCLogUpLoader.h"
NS_ASSUME_NONNULL_BEGIN

@class CCLogItem;
@interface CCAnalysisLogClient : NSObject

+ (void)registLogUploader:(id<CCLogUpLoader>)logUploader;
+ (void)unregistLogUploader:(id<CCLogUpLoader>)logUploader;
+ (void)clearAllUploader;

+ (void)uploadLog:(__kindof CCLogItem *)logItem;

@end

NS_ASSUME_NONNULL_END
