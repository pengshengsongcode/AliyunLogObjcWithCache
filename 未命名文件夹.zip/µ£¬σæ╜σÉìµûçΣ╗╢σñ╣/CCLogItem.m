
#import "CCLogItem.h"

@implementation CCLogItem

+ (instancetype)logItemWithData:(id)data {
    CCLogItem *logItem = [[CCLogItem alloc] init];
    logItem.data = data;
    return logItem;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _metaInfo = @{}.mutableCopy;
    }
    return self;
}

@end
