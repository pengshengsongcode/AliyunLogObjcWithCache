#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CCLogItem : NSObject

@property (nonatomic, copy) NSDictionary *data;

@property (nonatomic, strong, readonly) NSMutableDictionary *metaInfo;


+ (instancetype)logItemWithData:(id)data;

@end

NS_ASSUME_NONNULL_END
