#import <Foundation/Foundation.h>
#import "CCLogUpLoader.h"

typedef NS_ENUM(NSInteger, CCAliLogSerializerType) {
    CCAliLogSerializerTypeJSON,
    CCAliLogSerializerTypeProtobuf
};

NS_ASSUME_NONNULL_BEGIN

@interface CCAliYunUploader : NSObject
<CCLogUpLoader>

+ (instancetype)sharedInstance;

@property (nonatomic, copy) NSString *endPoint;
@property (nonatomic, copy) NSString *aliYunAccessKey;
@property (nonatomic, copy) NSString *accessKeySecret;
@property (nonatomic, copy) NSString *projectName;
//default:CCAliLogSerializerTypeJSON
@property (nonatomic, assign) CCAliLogSerializerType serializeType;
@property (nonatomic, copy) NSString *topic;
@property (nonatomic, copy) NSString *source;

//default:NO
@property (nonatomic, assign) BOOL showLog;

- (void)setup;

@end

NS_ASSUME_NONNULL_END
