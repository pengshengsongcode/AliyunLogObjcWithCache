

#import "CCAnalysisLogClient.h"

@interface CCAnalysisLogClient ()

@property (nonatomic, strong) NSMutableArray<id<CCLogUpLoader>> *uploaderList;

@end

@implementation CCAnalysisLogClient

+ (void)registLogUploader:(id<CCLogUpLoader>)logUploader {
    [[self sharedInstance] registLogUploader_:logUploader];
}
+ (void)unregistLogUploader:(id<CCLogUpLoader>)logUploader {
    [[self sharedInstance] unregistLogUploader_:logUploader];
}
+ (void)clearAllUploader {
    [[self sharedInstance] clearAllUploader_];
}

+ (void)uploadLog:(__kindof CCLogItem *)logItem {
    [[self sharedInstance] uploadLog_:logItem];
}

+ (instancetype)sharedInstance {
    static CCAnalysisLogClient *logClient = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        logClient = [[CCAnalysisLogClient alloc] init];
    });
    return logClient;
}

- (void)registLogUploader_:(id<CCLogUpLoader>)logUploader {
    if (!logUploader || [_uploaderList containsObject:logUploader]) {
        return;
    }
    [_uploaderList addObject:logUploader];
}
- (void)unregistLogUploader_:(id<CCLogUpLoader>)logUploader {
    if (!logUploader) {
        return;
    }
    [_uploaderList removeObject:logUploader];
}
- (void)clearAllUploader_ {
    [_uploaderList removeAllObjects];
}

- (void)uploadLog_:(__kindof CCLogItem *)logItem {
    if (!logItem) {
        return;
    }
    __weak typeof(self)weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        for (id<CCLogUpLoader> uploader in weakSelf.uploaderList) {
            [uploader uploadLog:logItem];
        }
    });
}


#pragma mark - list
- (instancetype)init {
    self = [super init];
    
    _uploaderList = @[].mutableCopy;
    
    return self;
}
@end
