
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (ALYExts)

- (NSString *)aly_JSONString;

- (NSInteger)aly_integerForKey:(NSString *)key;
- (NSInteger)aly_integerForKey:(NSString *)key withDefaultValue:(NSInteger)dv;

- (double)aly_doubleForKey:(NSString *)key;
- (double)aly_doubleForKey:(NSString *)key withDefaultValue:(double)dv;

- (BOOL)aly_boolForKey:(NSString *)key;
- (BOOL)aly_boolForKey:(NSString *)key withDefaultValue:(BOOL)dv;

- (NSString *)aly_stringForKey:(NSString *)key;
- (NSString *)aly_stringForKey:(NSString *)key withDefaultValue:(NSString *)dv;

- (NSArray *)aly_arrayForKey:(NSString *)key;
- (NSArray *)aly_arrayForKey:(NSString *)key withDefaultValue:(NSArray *)dv;

- (NSDictionary *)aly_dictionaryForKey:(NSString *)key;
- (NSDictionary *)aly_dictionaryForKey:(NSString *)key withDefaultValue:(NSDictionary *)dv;

@end

NS_ASSUME_NONNULL_END
