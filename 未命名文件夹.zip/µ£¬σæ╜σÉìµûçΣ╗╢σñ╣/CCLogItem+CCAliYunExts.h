
#import "CCLogItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCLogItem (CCAliYunExts)

@property (nonatomic, copy) NSString *logStore;
@property (nonatomic, copy, readonly) NSString *aly_currentTime;

@property (nonatomic, copy) NSString *aliLogEventName;

@end

NS_ASSUME_NONNULL_END
