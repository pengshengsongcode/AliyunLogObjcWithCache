
#import "CCLogItem+CCAliYunExts.h"

@implementation CCLogItem (CCAliYunExts)

- (void)setLogStore:(NSString *)logStore {
    if (logStore.length < 1) {
        return;
    }
    [self.metaInfo setObject:logStore forKey:@"logStore"];
}

- (NSString *)logStore {
    return [self.metaInfo objectForKey:@"logStore"];
}

- (NSString *)aly_currentTime {
    return [NSString stringWithFormat:@"%.0f", [[NSDate date] timeIntervalSince1970] * 1000];
}

- (void)setAliLogEventName:(NSString *)eventName {
    if (eventName.length < 1) {
        return;
    }
    [self.metaInfo setObject:eventName forKey:@"aliLogEventName"];
}

- (NSString *)aliLogEventName {
    return [self.metaInfo objectForKey:@"aliLogEventName"];
}

@end
