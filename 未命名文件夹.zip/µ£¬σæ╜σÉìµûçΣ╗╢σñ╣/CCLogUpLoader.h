
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class CCLogItem;
@protocol CCLogUpLoader <NSObject>

@required
- (void)uploadLog:(__kindof CCLogItem *)logItem;

@end

@interface CCLogUpLoader : NSObject

@end

NS_ASSUME_NONNULL_END
