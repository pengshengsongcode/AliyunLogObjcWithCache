

#import "CCAliYunUploader.h"
#import "CCLogItem.h"
#import "CCLogItem+CCAliYunExts.h"
#import "LogClient.h"
#import "RawLog.h"
#import "RawLogGroup.h"
#import "NSDictionary+ALYExts.h"

@interface CCAliYunUploader ()

@property (nonatomic, strong) LogClient *logClient;

@end

@implementation CCAliYunUploader

+ (instancetype)sharedInstance {
    static CCAliYunUploader *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CCAliYunUploader alloc] init];
    });
    return instance;
}

- (void)setup {
    AliSLSSerializer type = AliSLSJSONSerializer;
    if (_serializeType == CCAliLogSerializerTypeProtobuf) {
        type = AliSLSProtobufSerializer;
    }
    _logClient = [[LogClient alloc] initWithApp: _endPoint
                                    accessKeyID: _aliYunAccessKey
                                accessKeySecret: _accessKeySecret
                                    projectName: _projectName
                                  serializeType: type];
}

- (void)uploadLog:(__kindof CCLogItem *)logItem {
    
    if (![self uploadCheck:logItem]) {
        return;
    }
    
    RawLogGroup *logGroup = [[RawLogGroup alloc] initWithTopic:self.topic andSource:self.source];
    
    RawLog *rawLog = [[RawLog alloc] init];
    
    [rawLog PutContent:logItem.aly_currentTime withKey:@"currentTime"];
    
    NSString *dataString = [logItem.data aly_JSONString];
    if (dataString.length < 1) {
        if (_showLog) {
            NSLog(@"aliLog====:logItem.data 序列化失败：%@", logItem.data);
        }
        return;
    }
    
    [rawLog PutContent:dataString withKey:logItem.aliLogEventName];
    
    [logGroup PutLog:rawLog];
    
    __weak typeof(self)weakSelf = self;
    [_logClient PostLog:logGroup logStoreName:logItem.logStore call:^(NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (weakSelf.showLog) {
            if (error) {
                NSLog(@"阿里云日志上传失败, URL: %@,Error:%@,log:->%@<-",[response description], [error description], logItem.data);
            }else {
                NSLog(@"阿里云日志上传成功, log:->%@<-",logItem.data);
            }
        }
        
    }];
}

- (BOOL)uploadCheck:(__kindof CCLogItem *)logItem {
    if (!_logClient) {
        NSLog(@"aliLog====:_logClient 初始化失败，无法上传log。。。");
        return NO;
    }
    
    if (logItem.logStore.length < 1) {
        if (_showLog) {
            NSLog(@"aliLog====:logStore not set....");
        }
        return NO;
    }
    
    if (logItem.aliLogEventName.length < 1) {
        if (_showLog) {
            NSLog(@"aliLog====:logItem.aliLogEventName is nil....");
        }
        return NO;
    }
    
    if (!logItem.data) {
        if (_showLog) {
            NSLog(@"aliLog====:logItem.data is nil....");
        }
        return NO;
    }
    return YES;
}

@end
