
#import "NSDictionary+ALYExts.h"

@implementation NSDictionary (ALYExts)

- (NSString *)aly_JSONString {
    if ([NSJSONSerialization isValidJSONObject:self]) {
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self options:kNilOptions error:&error];
        if (error != nil) {
            return nil;
        }
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    }
    return nil;
}

- (NSInteger)aly_integerForKey:(NSString *)key {
    return [self aly_integerForKey:key withDefaultValue:0];
}
- (NSInteger)aly_integerForKey:(NSString *)key withDefaultValue:(NSInteger)dv {
    id v = [self valueForKey:key]; if (v == nil) return dv;
    if ([v isKindOfClass:[NSNumber class]]) {
        return [((NSNumber *)v) integerValue];
    }else {
        if ([v isKindOfClass:[NSString class]]) {
            return [((NSString *)v) integerValue];
        }
    }
    return dv;
}

- (double)aly_doubleForKey:(NSString *)key {
    return [self aly_doubleForKey:key withDefaultValue:0];
}
- (double)aly_doubleForKey:(NSString *)key withDefaultValue:(double)dv {
    id v = [self valueForKey:key]; if (v == nil) return dv;
    if ([v isKindOfClass:[NSNumber class]]) {
        return [((NSNumber *)v) doubleValue];
    }else {
        if ([v isKindOfClass:[NSString class]]) {
            return [((NSString *)v) doubleValue];
        }
    }
    return dv;
}

- (BOOL)aly_boolForKey:(NSString *)key {
    return [self aly_boolForKey:key withDefaultValue:NO];
}
- (BOOL)aly_boolForKey:(NSString *)key withDefaultValue:(BOOL)dv {
    id v = [self valueForKey:key]; if (v == nil) return dv;
    if ([v isKindOfClass:[NSNumber class]]) {
        return [((NSNumber *)v) boolValue];
    }else {
        if ([v isKindOfClass:[NSString class]]) {
            return [((NSString *)v) boolValue];
        }
    }
    return dv;
}

- (NSString *)aly_stringForKey:(NSString *)key {
    return [self aly_stringForKey:key withDefaultValue:@""];
}
- (NSString *)aly_stringForKey:(NSString *)key withDefaultValue:(NSString *)dv {
    id v = [self valueForKey:key]; if (v == nil) return dv;
    if ([v isKindOfClass:[NSString class]]) {
        return (NSString *)v;
    } else if ([v isKindOfClass:[NSNumber class]]) {
        return [NSString stringWithFormat:@"%@",v];
    }
    return dv;
}

- (NSArray *)aly_arrayForKey:(NSString *)key {
    return [self aly_arrayForKey:key withDefaultValue:[NSArray array]];
}
- (NSArray *)aly_arrayForKey:(NSString *)key withDefaultValue:(NSArray *)dv {
    id v = [self valueForKey:key]; if (v == nil) return dv;
    if ([v isKindOfClass:[NSArray class]]) {
        return (NSArray *)v;
    }
    return dv;
}

- (NSDictionary *)aly_dictionaryForKey:(NSString *)key {
    return [self aly_dictionaryForKey:key withDefaultValue:[NSDictionary dictionary]];
}
- (NSDictionary *)aly_dictionaryForKey:(NSString *)key withDefaultValue:(NSDictionary *)dv {
    id v = [self valueForKey:key]; if (v == nil) return dv;
    if ([v isKindOfClass:[NSDictionary class]]) {
        return (NSDictionary *)v;
    }
    return dv;
}

@end
